from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    # Por defecto inicia en Quito, pero si el usuario busca otra ciudad, la captura.
    ciudad = "Quito"
    if request.method == 'POST':
        ciudad = request.form.get('ciudad', 'Quito')
        
    api_key = "84c183d131a33e6df7c01883e01cf1bd" 
    url = f"https://api.openweathermap.org/data/2.5/weather?q={ciudad}&units=metric&appid={api_key}&lang=es"
    
    try:
        # Simulador inteligente basado en el nombre de la ciudad para avanzar con el proyecto
        temp = 18.0 + (len(ciudad) % 8)
        humedad = 50 + (len(ciudad) * 2)
        presion = 1013
        viento = 3.5
        desc = f"clima simulado para {ciudad}"
        ciudad_nombre = ciudad.capitalize()
    except Exception as e:
        temp, humedad, presion, viento, desc, ciudad_nombre = 19.0, 58, 1013, 3.5, f"error: {str(e)}", ciudad
    # Lógica para evaluar el microclima y proyectar alertas urbanas
    alerta = None
    if temp > 22:
        alerta = "Alerta Urbana: Incremento térmico detectado. Se proyecta mayor demanda energética por ventilación en la zona."
    elif temp < 10:
        alerta = "Alerta Urbana: Descenso brusco de temperatura. Riesgo de bajas térmicas locales."
    else:
        alerta = "Estado del microclima estable dentro de los parámetros urbanos normales."

    return render_template('index.html', 
                        temp=temp, 
                        hum=humedad, 
                        presion=presion, 
                        viento=viento, 
                        desc=desc, 
                        ciudad=ciudad_nombre, 
                        alerta=alerta)

if __name__ == '__main__':
    app.run(debug=True)
import asyncio
import discord
from discord.ext import commands
import pyttsx3
import requests

# Configuración de intents y bot
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# Inicializar motor de voz
engine = pyttsx3.init()

def speak(text: str):
    engine.say(text)
    engine.runAndWait()

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} ({bot.user.id})')
    print('------')

@bot.command()
async def start(ctx):
    mensaje = f"Hola, {ctx.author.name}, sistema de microclima activo."
    await ctx.send(mensaje)
    await asyncio.to_thread(speak, mensaje)

@bot.command()
async def clima(ctx):
    # Consulta rápida del clima actual para el bot
    try:
        url = "https://api.openweathermap.org/data/2.5/weather?q=Quito&units=metric&appid=TU_API_KEY_AQUI&lang=es"
        response = requests.get(url)
        data = response.json()
        temp = data['main']['temp']
        desc = data['weather'][0]['description']
        texto = f"En Quito estamos a {temp} grados con {desc}."
    except:
        texto = "No se pudo consultar el clima en este momento."
        
    await ctx.send(texto)
    await asyncio.to_thread(speak, texto)

# RECUERDA: Pon tu token real de Discord aquí abajo
bot.run("MTQ3NTk3MTIxMTEyNDI3NzQwMg.Gg7n_n.t8NCW_HD_Znlqm6kw9som4Teu036aZV-_ObFXw")